<?php
// TODO Zorg dat de methodes goed ingevuld worden met de juiste queries.
function getCategories()
{
    global $pdo;
    $query = $pdo->prepare("SELECT * FROM  catagories");
    $query->execute();
    return $query->fetchAll(PDO::FETCH_CLASS, 'Category');
}

function getCategoryName(int $id)
{

}
